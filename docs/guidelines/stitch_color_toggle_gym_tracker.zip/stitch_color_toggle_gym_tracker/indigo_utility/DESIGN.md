---
name: Indigo Utility
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#464554'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#777586'
  outline-variant: '#c7c4d7'
  surface-tint: '#5148d7'
  primary: '#2a14b4'
  on-primary: '#ffffff'
  primary-container: '#4338ca'
  on-primary-container: '#c1beff'
  inverse-primary: '#c3c0ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#692400'
  on-tertiary: '#ffffff'
  tertiary-container: '#8f3400'
  on-tertiary-container: '#ffb393'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#100069'
  on-primary-fixed-variant: '#372abf'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb597'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 16px
  gutter: 16px
---

## Brand & Style

This design system is engineered for high-utility applications where clarity, efficiency, and functional reliability are paramount. The brand personality is professional, systematic, and unobtrusive, acting as a sophisticated framework for data-dense information and color-specific workflows.

The visual direction follows a **Corporate / Modern** aesthetic, specifically a "Bootstrap-plus" evolution. This means retaining the familiarity of standard web patterns while elevating them through refined spacing, purposeful depth, and a high-fidelity Indigo core. The interface prioritizes scanning speed and touch accuracy, ensuring that the utility of the tool is never compromised by its aesthetics. It aims to evoke a sense of precision and professional-grade capability.

## Colors

The palette is anchored by a deep Indigo primary, used for the UI shell, headers, and primary actions to establish a professional foundation. The background uses a very light slate neutral to reduce eye strain and provide better contrast for card-based layouts.

Functional utility colors (Red, Blue, Green, Yellow, Purple, Orange) are reserved for state indicators, color-specific toggles, and data categorization. They must maintain high contrast against white backgrounds. 

**Color Usage Rules:**
- **Primary Indigo:** Navigation bars, active tab states, and primary buttons.
- **Secondary Slate:** Text descriptions, icons, and secondary actions.
- **Utility Palette:** Used strictly for color tiles, toggle-specific states, and status badges.
- **Passive State:** Uses a muted slate to clearly differentiate from Active (Green) states.

## Typography

The design system utilizes **Inter** for all typographic roles. Inter's tall x-height and excellent legibility make it ideal for utility apps where users need to process data quickly.

**Type Hierarchy:**
- **Display/Headline:** Use for page titles and large data points.
- **Body:** Standardized at 14px (md) for density and 16px (lg) for reading-heavy sections.
- **Labels:** Used for status badges, table headers, and form labels. Small labels use uppercase with slight tracking to improve readability at small scales.

Weight is used as the primary tool for hierarchy: Semibold (600) for headers and interactive labels, and Regular (400) for descriptive text.

## Layout & Spacing

The system employs a **Fluid Grid** model based on a 4px baseline. Most components utilize 8px (sm) or 16px (md) increments to ensure vertical and horizontal rhythm.

**Layout Structure:**
- **Mobile:** Single column with 16px side margins. Cards span the full width of the container.
- **Tablet/Desktop:** 12-column grid. Components like cards should span 4 columns (3-up) or 6 columns (2-up) depending on the complexity of the data.
- **Density:** For utility screens, use "Compact" spacing (8px) between related inputs and "Relaxed" spacing (24px) between distinct sections.

Primary actions on mobile should maintain a minimum tap target of 48x48px to ensure accessibility in high-speed environments.

## Elevation & Depth

This design system uses a combination of **low-contrast outlines** and **ambient shadows** to create a structured, layered feel.

- **Level 0 (Base):** Neutral background (#f8fafc).
- **Level 1 (Cards/Tiles):** White surface with a 1px border (#e2e8f0) and a subtle, soft shadow (Y: 2px, Blur: 4px, Opacity: 4%).
- **Level 2 (Hover/Active Cards):** Enhanced shadow (Y: 4px, Blur: 8px, Opacity: 8%) to indicate interactivity.
- **Level 3 (Navigation/Drawers):** Persistent surfaces like side navigation use a clean right-edge border rather than heavy shadows to maintain a "pinned" feeling.
- **Level 4 (Floating Action Buttons):** High-diffusion shadows (Y: 6px, Blur: 12px, Indigo-tinted) to separate primary actions from the map or list content.

## Shapes

The design system uses a **Rounded** (0.5rem / 8px) corner language. This provides a balance between the precision of sharp corners and the friendliness of fully rounded ones.

- **Buttons & Inputs:** 8px (base) corner radius.
- **Cards & Modals:** 16px (rounded-lg) for larger containers.
- **Badges/Chips:** 9999px (pill-shaped) to distinguish them from interactive buttons.
- **Selection Tiles:** 12px (rounded-md) for a distinct tactile feel when selecting color themes.

## Components

### Buttons & Actions
- **Primary Button:** Solid Indigo background, white text. 8px radius. High-contrast and bold.
- **Secondary Button:** White background, Indigo border, Indigo text.
- **Floating Action Button (FAB):** Circular, Indigo background, white icon. Used for primary map/list triggers.
- **Tap Targets:** Minimum 44px height for all mobile buttons.

### Cards & Lists
- **Utility Card:** White background, 1px border (#e2e8f0), 8px shadow. Includes a 4px colored accent bar on the left edge to denote the active "color toggle."
- **List Items:** Divided by subtle 1px horizontal lines. High density with 12px vertical padding.

### Inputs & Toggles
- **Input Fields:** 1px border (#cbd5e1), focus state uses a 2px Indigo ring.
- **Color Toggles:** Large, tactile square tiles. When active, they show a thick Indigo border and a checkmark icon.

### Status & Feedback
- **Badges:** Small, pill-shaped labels. "Active" uses a green background tint; "Passive" uses a light gray.
- **Toasts/Alerts:** Success (Green), Error (Red), and Info (Indigo) banners that slide from the top. 
- **Loading:** A clean, 2px Indigo stroke spinner with a consistent medium speed.

### Navigation
- **Header:** Fixed Indigo bar with white typography and icons.
- **Drawer:** Clean white surface, 1px right border, using Indigo for active list item backgrounds and text.